class EX01{

    public static void main(String[] args) {
		
        int num1 = 10;
        int num2 = 5;
        boolean flag = true;
        int result = 0;
		
		System.out.println("Unary Operators ");
        System.out.println("num1++: " + num1++); 
        System.out.println("++num1: " + ++num1); 
        System.out.println("num2--: " + num2--); 
        System.out.println("--num2: " + --num2); 
        System.out.println("!flag: " + !flag);   

        System.out.println("\n Logical Operators ");
        boolean andResult = (num1 > 5) && (num2 < 10); 
        System.out.println("(num1 > 5) && (num2 < 10): " + andResult); 
        boolean orResult = (num1 < 5) || (num2 > 10);  
        System.out.println("(num1 < 5) || (num2 > 10): " + orResult);  

 
        System.out.println("\n Relational Operators ");
        System.out.println("num1 > num2: " + (num1 > num2));  
        System.out.println("num1 < num2: " + (num1 < num2));  
        System.out.println("num1 == num2: " + (num1 == num2)); 
        System.out.println("num1 != num2: " + (num1 != num2)); 
        System.out.println("num1 >= num2: " + (num1 >= num2)); 
        System.out.println("num1 <= num2: " + (num1 <= num2)); 

        System.out.println("\n Assignment Operators ");
        result = num1;
        System.out.println("result = num1: " + result); 
        result += num2; 
        System.out.println("result += num2: " + result); 
        result -= num2; 
        System.out.println("result -= num2: " + result); 
        result *= num2; 
        System.out.println("result *= num2: " + result); 
        result /= num2; 
        System.out.println("result /= num2: " + result); 
        result %= num2; 
        System.out.println("result %= num2: " + result); 
		
		System.out.println("\n Ternary Operator ");
        String message = (num1 > num2) ? "num1 is greater than num2" : "num1 is not greater than num2";
        System.out.println(message); 
    }
}