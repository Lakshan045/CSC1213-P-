class EX05{
    public static void main(String[] args){
		System.out.println("Name: Damith \nLast Name: Lakshan \nAddress: No.124/A,Right bank,Pemaduwa,Anuradhapura");
	}
}