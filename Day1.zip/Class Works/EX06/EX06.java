class EX06{
	public static void main(String[] args){
		int a=20;
		int b=5;
		System.out.println("Addition is:"+(a+b));
		System.out.println("Substraction is:"+(a-b));
		System.out.println("Multiplication is:"+(a*b));
		System.out.println("Division is:"+(a/b));
		System.out.println("Modulation is:"+(a%b));
	}
}
		