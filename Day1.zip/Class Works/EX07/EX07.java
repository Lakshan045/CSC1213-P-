class EX07{
	public static void main(String[] args){
		char a1='g';
		System.out.println("The character is:"+a1);
		
		int int1=(int)a1;
		System.out.println("The character is:"+int1);
		
		double d1=12.02;
		System.out.println("The value is:"+d1);
		
		int int2=(int)d1;
		System.out.println("The value is:"+int2);
		
		double d2=int1;
		System.out.println("The value is:"+d1);
	}
}