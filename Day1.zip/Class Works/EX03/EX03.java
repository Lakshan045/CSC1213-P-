class EX03{
	public static void main(String[] args){
		boolean isBool=true;
		System.out.println("Boolean : "+ isBool);
		
		byte Byteval=120;
		System.out.println("Byte : "+ Byteval);
		
		int Intval=1;
		System.out.println("Integer : "+ Intval);
		
		short shortval=12345;
		System.out.println("short : "+ shortval);
		
		long longval=10000;
		System.out.println("long : "+ longval);
		
		float Floatval= (float)19.12;
		System.out.println("Float : "+ Floatval);
		
		double Doubleval=152.342;
		System.out.println("Double : "+ Doubleval);
		
		char charval='D';
		System.out.println("char  : "+ charval);
		
		char charval1='\u0063';
		System.out.println("char : "+ charval1);
	}
}
		
		
		