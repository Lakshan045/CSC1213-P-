class EX02{
	public static void main(String[] args){
		String fac="FAS";
		int a=10;
		int b=5;
		double c=1.2;
		char d='&';
		boolean isTH=true;
		
		System.out.println(fac);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(isTH);
		
		System.out.println("My Faculty is "+fac);
		System.out.println("My result1 is "+(a+b));
		System.out.println("My result2 is "+(a+c));
		
	}
}
		
		