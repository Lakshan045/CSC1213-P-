class EX04{
	public static void main(String[] args){
		
		String Name="Damith Lakshan";
		String RegNo="2022/ASP/27";
		String Degree="BSc.Applied Mathematics and Computing";
		
		System.out.println("Full Nmae: "+ Name);
		System.out.println("Registration Number: "+ RegNo); 
		System.out.println("Degree program is : " + Degree);
	}
}